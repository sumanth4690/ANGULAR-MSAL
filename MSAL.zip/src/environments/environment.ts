export const environment = {
  production: false,
  clientId:'826ec22f-1f33-4e97-80df-b5c02df4213d',
  // clientId: '68f7dbed-6f6e-4c8e-ba02-012fd8df98a8',
  authority: 'https://login.microsoftonline.com/{8f6bd982-92c3-4de0-985d-0e287c55e379}/',
  redirectUri: 'http://localhost:4200',
  scopes:['User.Read','user.read', 'mail.read','User.ReadBasic.All']
};